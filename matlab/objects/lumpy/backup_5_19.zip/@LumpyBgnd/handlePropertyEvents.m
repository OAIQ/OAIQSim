function handlePropertyEvents(src,evnt)
    switch src.Name 
        case 'Kbar'
            % Kbar is changed, re-randomize centers
            evnt.AffectedObject.randomize();
        case 'rb2'
            % rb2 is changed, make sure it's the right size
            if(length(evnt.AffectedObject.rb2)==1)
            evnt.AffectedObject.rb2 = evnt.AffectedObject.rb2*ones(evnt.AffectedObject.dim,1);  
            end
            if(length(evnt.AffectedObject.rb2)==evnt.AffectedObject.dim)    
            evnt.AffectedObject.rb2 = reshape(evnt.AffectedObject.rb2,[evnt.AffectedObject.dim,1]);  
            end
            % Need to re-randomize centers because the edge padding is
            % now different
            warning('The lump radius has been changed; edge effects may occur! Recommend re-randomizing.');
            %evnt.AffectedObject.randomize();
        case 'b0'
            % b0 is changed, make sure it's the right size
            if(length(evnt.AffectedObject.b0)~=evnt.AffectedObject.K)
                evnt.AffectedObject.b0 = evnt.AffectedObject.b0*ones(evnt.AffectedObject.K,1);
            end
    end
end