% ---------------------------------------------------------------------------
% **********************CGRI SIMULATION TOOLBOX***************************
% u = LumpyBgnd(). The lumpy background object.
%  **** UPDATE ****
% u = LumpyBgnd(X,varargin) evaluates a lumpy background image at the
% coordinates in the N-by-d matrix X.
% The name-value pairs in varargin determine if the background is generated
% from scratch or using pre-determined lump centers.
%   ex: [u,c] = LumpyBgnd(X,'Kbar',100,'b0',1,'B0',0,'rb2',0.001); 
%   generates a random lumpy background from scratch with the parameters 
%   (Kbar,b0,B0,rb2) = (100,1,0,0.001), evaluted at the coordinates X.  X
%   is N-by-d, with each row being an evaluation point (x,y) or (x,y,z)
%   ex: u = LumpyBgnd(X,'centers',c,'b0',1,'B0',0,'rb2',0.001); evalutes a
%   lumpy background with pre-determined lump centers c (K-by-d) and lump
%   parameters (b0,B0,rb2);
% If gpu = 1 and a gpu is available, the CUDA version is used.
% 
% (UPGRADE TO GRIDDATA)

% File: LumpyBgnd.m
% Author:  Nick Henscheid
% Date:    9-2016
% Contact: nhenscheid@math.arizona.edu
% This software is in the public domain, furnished "as is", without technical
% support, and with no warranty, express or implied, as to its usefulness for
% any purpose.
% ---------------------------------------------------------------------------

classdef LumpyBgnd < handle
    properties (SetObservable = true)
        b0   % Lump "Amplitude" (assuming constant for classical LBG)
        B0   % DC offset
        rb2  % Lump "width" (assuming constant for classical LBG)
        Kbar % Mean number of lumps
        centers % Lump centers
        gpu  % Evaluate using gpu or not
        N    % Default number of eval. pts in ea. direction 
        S    % Support set for evaluation
        israndnumlumps = 1 % Compute random number of lumps?
        %K       % Actual number of lumps
    end
    
    properties (Dependent)
        L;% Bounding box for evaluation (lump centers can extend slightly beyond to avoid edge effect issues)
        dim; 
        K; 
    end

    properties (SetAccess=private)
        padfactor = 3;
    end
    
    % Standard methods
    methods
        function obj = LumpyBgnd(varargin)
            p = obj.parseInputs(varargin{:});
            obj.Kbar    = p.Results.Kbar;
            obj.b0      = p.Results.b0;
            obj.B0      = p.Results.B0;
            obj.S       = p.Results.S;
            if(numel(p.Results.rb2)==1)
                % dim-by-K matrix (diagonal covariance)
                obj.rb2 = p.Results.rb2*ones(obj.S.dim,1);
            else
                obj.rb2 = p.Results.rb2;
            end
            obj.centers = p.Results.centers;
            obj.centers;
            
            if(gpuDeviceCount()>0)
                obj.gpu     = p.Results.gpu;
            else
                obj.gpu     = 0;
            end
            obj.N       = p.Results.N;
            if(numel(obj.centers)==0)
                % Need to generate random lump centers
                obj.randomize();
            end
            addlistener(obj,'Kbar','PostSet',@LumpyBgnd.handlePropertyEvents);
            addlistener(obj,'rb2','PostSet',@LumpyBgnd.handlePropertyEvents);
        end
        
        function val = get.L(obj)
            val = obj.S.L;
        end
        
        function val = get.dim(obj)
            val = obj.S.dim;
        end
        
        function val = get.K(obj)
            val = size(obj.centers,1);
        end
        
        function set.K(obj,value)
            if(isnumeric(value)&&value>=0&&(mod(value,1)==0))
                obj.K = value;
            else
                error('Invalid K value');
            end
        end
        
        function set.gpu(obj,value)
            if(isnumeric(value)||islogical(value))
                if(value==1||value==true)
                    if(gpuDeviceCount>0)
                        obj.gpu = value;
                    end
                elseif(value==0||value==false)
                    obj.gpu = value;
                else
                    error('Invalid value for gpu!');
                end
            else
                error('Invalid value for gpu!');
            end
        end
        
        % Externally defined functions
        p = parseInputs(varargin);
        u = eval(obj,X,XSize);
        obj = randomize(obj)
        varargout = plot(obj,alpha);
        z = minus(x,y);  % Method to subtract two lumpy backgrounds
        z = plus(x,y);   % Method to add two lumpy backgrounds
        
        function k = corrfun(obj,dr)
            % Computes the correlation function at a given delta-r 
            % See Rolland & Barrett JOSA A 1992
            k = (obj.Kbar*obj.b0^2/(2*pi*obj.rb2^2))*exp(-dr.^2/(2*obj.rb2^2)); 
        end
        
        function U = sample(obj,Ns)
            % Generates Ns samples of the lumpy background, returning it in
            % a cell array U (U{i} is a sample for each i)
            U = cell(Ns,1);
            for i=1:Ns
                obj.randomize;
                U{i} = obj.eval;
            end
        end
    end
    
    % Static methods
    methods (Static)
        handlePropertyEvents(src,evnt);   % Defined externally
    end
    
end