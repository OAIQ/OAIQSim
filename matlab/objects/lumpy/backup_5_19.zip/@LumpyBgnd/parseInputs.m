function p = parseInputs(~,varargin)
    p = inputParser;
    p.CaseSensitive = true;
    Kbar_default    = 100;
    b0_default      = 1;
    B0_default      = 0;
    rb2_default     = 0.005;
    centers_default = [];
    gpu_default     = 0;
    N_default       = 128;
    L_default       = [0,1;0,1];
    S_default       = RectSupport([0,1;0,1]);
    isnonneg        = @(x) (x>=0);
    ispos           = @(x) (x>0);
    isbinary        = @(x) (x==0||x==1);
    addParameter(p,'b0',b0_default,isnonneg);
    addParameter(p,'B0',B0_default,isnonneg);
    addParameter(p,'rb2',rb2_default,ispos);
    addParameter(p,'Kbar',Kbar_default,ispos);
    addParameter(p,'centers',centers_default,@isnumeric);
    addParameter(p,'gpu',gpu_default,isbinary);
    addParameter(p,'N',N_default,ispos);
    addParameter(p,'L',L_default,@isnumeric);
    addParameter(p,'S',S_default,@(x) 1);
    addParameter(p,'pdf',false,@islogical);
    parse(p,varargin{:});
end